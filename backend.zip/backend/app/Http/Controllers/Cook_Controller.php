<?php

namespace App\Http\Controllers;

use App\Models\Cook;
use App\Http\Controllers\Controller;
use App\Http\Requests\Cook_Request;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class Cook_Controller extends Controller
{
    public function index()
    {
        $cooks = Cook::all();

        return view('cooks.index', compact('cooks'));
    }

    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'specialty' => 'required|max:255',
        ]);

        // Create a new cook
        $cook = new Cook;
        $cook->name = $validatedData['name'];
        $cook->specialty = $validatedData['specialty'];
        $cook->save();

        return redirect()->route('cooks.index')->with('success', 'Cook created successfully');
    }

    public function destroy($id)
    {
        $cook = Cook::findOrFail($id);
        $cook->delete();

        return redirect()->route('cooks.index')->with('success', 'Cook deleted successfully');
    }
}
